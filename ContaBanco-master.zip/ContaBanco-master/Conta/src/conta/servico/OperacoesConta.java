package conta.servico;

import conta.modelo.Conta;

public interface OperacoesConta{
	
	public void salvar(Conta conta);
	
	

}
